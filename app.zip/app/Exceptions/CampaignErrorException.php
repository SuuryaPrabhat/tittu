<?php

namespace Acelle\Exceptions;

class CampaignErrorException extends \Exception
{

}
