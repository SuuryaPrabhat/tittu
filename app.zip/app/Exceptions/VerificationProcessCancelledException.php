<?php

namespace Acelle\Exceptions;

class VerificationProcessCancelledException extends \Exception
{

}
