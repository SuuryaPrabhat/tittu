<?php

namespace Acelle\Exceptions;

class CampaignPausedException extends \Exception
{
    
}