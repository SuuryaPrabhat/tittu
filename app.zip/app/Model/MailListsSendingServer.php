<?php

namespace Acelle\Model;

use Illuminate\Database\Eloquent\Model;

class MailListsSendingServer extends Model
{
    //
}
